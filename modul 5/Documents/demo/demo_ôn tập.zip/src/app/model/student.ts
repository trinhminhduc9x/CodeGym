export interface Student {
  id?: number;
  name?: string;
  dateOfBirth?: string;
  point: number
}
